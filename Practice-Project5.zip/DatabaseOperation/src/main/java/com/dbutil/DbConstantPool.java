package com.dbutil;

public class DbConstantPool {
	public static final String DRIVER_CLASS = "com.mysql.cj.jdbc.Drivers";
	public static final String DB_URL = "jdbc:mysql://localhost:3306";
	public static final String USERNAME = "naveen";
	public static final String PASSWORD = "Haikyuu@555!";

}
