package com.dbutil;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBUtil {
	public static Connection dbCon()throws ClassNotFoundException, SQLException {
		Class.forName(DbConstantPool.DRIVER_CLASS);
		Connection Con = DriverManager.getConnection(DbConstantPool.DB_URL,DbConstantPool.USERNAME,DbConstantPool.PASSWORD);
		return Con;
	}

}
