package com.ecommerce;

public class dbConstantPool {
	
	public static final String DRIVER_CLASS = "com.mwsql.cj.jdbc.Drivers";
	public static final String DB_URL = "jdbc:mysql://localhost:3306/db3";
	public static final String USERNAME = "naveen";
	public static final String PASSWORD = "12345";

}
