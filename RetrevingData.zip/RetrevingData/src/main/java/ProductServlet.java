import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/ProductServlet")
public class ProductServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String productId = request.getParameter("productId");

        try {
            Connection conn = getConnection();
            String sql = "SELECT * FROM product WHERE id=?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, Integer.parseInt(productId));
            ResultSet rs = ps.executeQuery();

            PrintWriter out = response.getWriter();
            response.setContentType("text/html");

            if (rs.next()) {
                String productName = rs.getString("name");
                double productPrice = rs.getDouble("price");

                out.println("<html><body>");
                out.println("<h2>Product Details</h2>");
                out.println("<p>ID: " + productId + "</p>");
                out.println("<p>Name: " + productName + "</p>");
                out.println("<p>Price: $" + productPrice + "</p>");
                out.println("</body></html>");
            } else {
                out.println("<html><body>");
                out.println("<h2>Product Not Found</h2>");
                out.println("</body></html>");
            }

        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
    }

    private Connection getConnection() throws ClassNotFoundException, SQLException {
        String jdbcURL = "jdbc:mysql://localhost:3306/ecommerce";
        String jdbcUsername = "root";
        String jdbcPassword = "Haikyuu@555!";

        Class.forName("com.mysql.cj.jdbc.Driver");
        return DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
    }
}
